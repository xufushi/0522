from django.contrib import admin
# Register your models here.
from .models import MyIntroduction
class MyIntroductionAdmin(admin.ModelAdmin):
	list_display = ('name', 'phone_number', 'address','introduction_myself')



admin.site.register(MyIntroduction)

# Register your models here.
